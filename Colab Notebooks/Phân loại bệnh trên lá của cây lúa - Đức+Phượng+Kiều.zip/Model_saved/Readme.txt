Do hạn chế về kích thước tải lên, nên nhóm em upload model tại link drive sau ạ:
https://drive.google.com/drive/folders/1W7go1Bw0BikTV9zxtukvJVYpnN_erdk_?usp=sharing